//-------------------------------------------------------------//
//              NORD Electronic Drivesystems GmbH              //
//-------------------------------------------------------------//

Select the GDSML file for your device.


Supported Devices

GSDML V2.25 (GSDML-V2.25-NORD DRIVESYSTEMS-xUxPNT-20150603.xml):
- SK TU3-PNT
- SK CU4-PNT
- SK TU4-PNT

GSDML V2.35 (GSDML-V2.35-NORDDRIVESYSTEMS-PNT-20210215.xml):
- SK TU3-PNT (Firmware Version 2.x)
- SK CU4-PNT (Firmware Version 2.x)
- SK TU4-PNT (Firmware Version 2.x)
- SK TU4-PNS, SAFE device (also hardware variant SK CU4-PNS)
- NORDAC PRO, SK 550P
- NORDAC ON,  SK 300P

GSDML V2.41 (GSDML-V2.41-NORDDRIVESYSTEMS-PNT-20220812.xml):
- SK TU3-PNT (Firmware Version 2.x)
- SK CU4-PNT (Firmware Version 2.x)
- SK TU4-PNT (Firmware Version 2.x)
- SK TU4-PNS, SAFE device (also hardware variant SK CU4-PNS)
- NORDAC PRO, SK 550P
- NORDAC ON,  SK 300P
- SK CU4-ETH
- SK TU4-ETH

Change History
2011.06.24	SK TU3-PNT Original file 
2012.01.24	Bug: SK TU3-PNT PPO2 Module ID = 0xA
2012.09.10	SK TU4-PNT supported (+TU3), .bmp files updated
2013.04.22	MRP supported, TU3 + TU4 in one file
2013.09.09	SK CU4-PNT supported, SK TU4-PNT wrong order number corrected
2014.11.19	Safe index corrected, some descriptions (inputs/outputs) changed
2015.06.02	SK TU3-PNT with 8 Inverters
2017.02.14	SK TU4-PNS (PROFIsafe) GSDML only for PROFIsafe
2018.10.26	SK TU4-PNS (PROFIsafe) GSDML only for PROFIsafe (3 errors added)
2019.06.18	NORDAC PRO (SK 550P) GSDML PROFINET added
2020.11.24	NORDAC ON  (SK 300P) GSDML PROFINET added
2021.02.15	Two PROFIsafe errors added
2022.08.12	SK CU4-ETH and SK TU4-ETH added

